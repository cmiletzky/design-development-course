package exer_1.part_1;

public class A implements C {

    public A(){

    }

    public void f1(){

    }

    public void f2(){

    }

    public void f3(){

    }

}
