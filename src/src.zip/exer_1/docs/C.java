
public interface C {

    public void f1();
    public void f2();
}
