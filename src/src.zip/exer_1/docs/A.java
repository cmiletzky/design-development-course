
public class A implements C {

    public A(){

    }

    public void f1(){

    }

    public void f2(){

    }

    public void f3(){

    }

}
