//package exer_1.part_2;
//
//public class Test {
//    public static void main(String args[])
//    {
//       Animal an = new Bear(40, Season.WINTER);
//        System.out.println(an.getCurrentSeason());
//
//        an.changeSeason();
//       System.out.println(an.getCurrentSeason());
//       System.out.println(an);
//
//    }
//}
