package exer_1.part_2;

public interface Seasonable {
    Season getCurrentSeason();
    void changeSeason();
}

