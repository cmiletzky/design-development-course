package exer_1.part_2;

public enum Color {
    GRAY, BROWN, BLACK, WHITE, YELLOW, GREEN
}

