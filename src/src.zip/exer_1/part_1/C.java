package exer_1.part_1;

public interface C {

    public void f1();
    public void f2();
}
