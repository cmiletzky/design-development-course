public class Caribou extends Animal {

    Caribou(int weight, Season season) {
        // TODO: Implement.
        super(0, null, null);
    }

    @Override
    public String toString() {
        // TODO: Implement.
        return null;
    }

    @Override
    public void changeSeason() {
        // TODO: Implement.
    }
}
