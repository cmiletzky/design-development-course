public enum Season {
    WINTER, SPRING, SUMMER, FALL;
    // TODO: Add auxiliary functions.
}
