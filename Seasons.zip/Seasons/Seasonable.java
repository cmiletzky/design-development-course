public interface Seasonable {
    Season getCurrentSeason();
    void changeSeason();
}
