public enum Color {
    GRAY,BROWN,BLACK,WHITE,YELLOW,GREEN
}
